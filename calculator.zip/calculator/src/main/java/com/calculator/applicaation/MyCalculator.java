package com.calculator.applicaation;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MyCalculator {

	@GetMapping("/")
	public String loadCalci() {
		return "calculator.html";
	}

	@GetMapping("/{ap}")
	public String calculate(@PathVariable String ap, RedirectAttributes attributes, @RequestParam("num1") int x,
			@RequestParam("num2") int y) {
		System.err.println("Calculator-Logic Performed");
		attributes.addFlashAttribute("x", x);
		attributes.addFlashAttribute("y", y);
		attributes.addFlashAttribute("result", ap.equals("addtion") ? (x + y)
				: ap.equals("subtraction") ? (x - y) : ap.equals("multiply") ? (x * y) : (x / (double) y));
		return "redirect:/";
	}
}